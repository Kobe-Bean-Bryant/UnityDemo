#if TEST_FRAMEWORK_INSTALLED
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using JetBrains.Annotations;
using NUnit.Framework;
using PrimeTween;
using TMPro;
using UnityEditor;
using UnityEditor.Build.Player;
using UnityEditor.TestTools.TestRunner;
using UnityEditorInternal;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Assert = NUnit.Framework.Assert;
using Object = UnityEngine.Object;
using Random = UnityEngine.Random;

public class EditModeTests {
    [Test]
    public void BuildTargetCompiles() {
        const BuildTarget target = BuildTarget.StandaloneWindows64;
        var settings = new ScriptCompilationSettings {
            group = BuildPipeline.GetBuildTargetGroup(target),
            target = target,
            options = ScriptCompilationOptions.None
        };
        PlayerBuildInterface.CompilePlayerScripts(settings, $"other/builds/{target}");
    }

    [Test]
    public void TestEditMode() {
        Tween.StopAll();
        Assert.AreEqual(0, PrimeTweenManager.Instance.tweensCount);
        PrimeTweenConfig.warnEndValueEqualsCurrent = false;
        PrimeTweenConfig.warnZeroDuration = false;
        expectError();
        Tween.Custom(0, 1, 1, delegate {});
        var go = new GameObject();
        {
            expectError();
            Tween.Alpha(go.AddComponent<SpriteRenderer>(), 0, 1);
            expectError();
            Tween.Delay(1);
            expectError();
            Tween.Delay(0);
            expectError();
            Tween.CompleteAll();
            PrimeTweenConfig.warnEndValueEqualsCurrent = true;
            expectError();
            Tween.StopAll();
            expectError();
            Tween.SetPausedAll(true);
            expectError();
            Tween.ShakeLocalPosition(go.transform, Vector3.one, 1);
            expectError();
            Tween.ShakeCustom(go, Vector3.zero, new ShakeSettings(Vector3.one, 1), delegate {});
            expectError();
            Sequence.Create();
            // expectError();
            // Tween.GlobalTimeScale(0.5f, 0.1f);
            expectError();
            Tween.GetTweensCount(this);
            expectError();
            Tween.GetTweensCount();
            expectError();
            Sequence.Create(Tween.Delay(0.01f));

            TweenSettings.ValidateCustomCurveKeyframes(AnimationCurve.Linear(0, 0, 1, 1));
            PrimeTweenConfig.SetTweensCapacity(10);
            Assert.DoesNotThrow(() => PrimeTweenConfig.defaultEase = Ease.InCirc);
        }
        Object.DestroyImmediate(go);
        void expectError() {
        }
        LogAssert.NoUnexpectedReceived();
        PrimeTweenConfig.warnEndValueEqualsCurrent = true;
        PrimeTweenConfig.warnZeroDuration = true;
    }

    #if PRIME_TWEEN_PRO
    [UnityTest]
    public IEnumerator MixTargetsAndNoTargets() {
        var testParent = new GameObject(nameof(MixTargetsAndNoTargets));

        // regular animation with Data.targets populated
        {
            new GameObject("regular animation") { transform = { parent = testParent.transform } }
                .AddComponent<TweenAnimationComponent>().animation.animations.Add(new TweenAnimation.Data {
                tweenType = TweenAnimation.TweenType.PositionX,
                targets = new List<Object> { testParent.transform }
            });
        }

        // callback without targets
        new GameObject("callback") { transform = { parent = testParent.transform } }
                .AddComponent<TweenAnimationComponent>().animation.animations.Add(new TweenAnimation.Data {
            tweenType = TweenAnimation.TweenType.Callback
        });

        Selection.activeTransform = testParent.transform.GetChild(0);
        yield return WaitInEditor();
        Selection.activeTransform = testParent.transform.GetChild(1);
        yield return WaitInEditor();
        Selection.objects = testParent.GetComponentsInChildren<Transform>().Skip(1).Select(x => x.gameObject).ToArray();
        yield return WaitInEditor();
    }

    [UnityTest]
    public IEnumerator TweenAnimationComponentAnimations() {
        Type inspectorWindowType = typeof(Editor).Assembly.GetType("UnityEditor.InspectorWindow");
        new GameObject(nameof(AudioListener)).AddComponent<AudioListener>();
        bool testInspector = Random.value > 0.0f;
        var tweenTypes = Enum.GetValues(typeof(TweenAnimation.TweenType)).Cast<TweenAnimation.TweenType>();
        // TweenAnimation.TweenType[] tweenTypes = { TweenAnimation.TweenType.UIHorizontalNormalizedPosition };
        foreach (var tweenType in tweenTypes) {
            // Debug.Log(tweenType);
            (PropType propType, Type targetType) = Utils.TweenTypeToTweenData(tweenType);
            if (propType == PropType.Quaternion) {
                continue;
            }
            switch (tweenType) {
                case TweenAnimation.TweenType.Disabled:
                case TweenAnimation.TweenType.MainSequence:
                case TweenAnimation.TweenType.NestedSequence:
                case TweenAnimation.TweenType.TweenTimeScale:
                case TweenAnimation.TweenType.TweenTimeScaleSequence:
                case TweenAnimation.TweenType.VisualElementLayout:
                case TweenAnimation.TweenType.VisualElementPosition:
                case TweenAnimation.TweenType.VisualElementRotationQuaternion:
                case TweenAnimation.TweenType.VisualElementScale:
                case TweenAnimation.TweenType.VisualElementSize:
                case TweenAnimation.TweenType.VisualElementTopLeft:
                case TweenAnimation.TweenType.VisualElementColor:
                case TweenAnimation.TweenType.VisualElementBackgroundColor:
                case TweenAnimation.TweenType.VisualElementOpacity:
                #if PRIME_TWEEN_EXPERIMENTAL
                case TweenAnimation.TweenType.CustomDouble:
                #endif
                case TweenAnimation.TweenType.TweenAwaiter:
                case TweenAnimation.TweenType.GlobalTimeScale: // don't animate global time scale in tests
                    continue;
            }
            GameObject go;
            if (targetType == typeof(Renderer)) {
                go = GameObject.CreatePrimitive(PrimitiveType.Cube);
                go.name = tweenType.ToString();
            } else {
                go = new GameObject(tweenType.ToString());
            }
            var animationComponent = go.AddComponent<TweenAnimationComponent>(); // create as the first component on the GameObject for easier visual validation

            Object target = GetTarget();
            Object GetTarget() {
                if (tweenType == TweenAnimation.TweenType.MaterialPropertyVector4) {
                    return new Material(Shader.Find("ShaderWithVector4Property"));
                }
                if (targetType == typeof(Material)) {
                    return Resources.FindObjectsOfTypeAll<Material>().Single(x => x.name == "Default-Material");
                }
                if (targetType == typeof(Transform)) {
                    return go.GetComponent<Transform>();
                }
                if (targetType == typeof(TMP_Text)) {
                    var text = go.AddComponent<TextMeshPro>();
                    const string str = "0123456789012345678901234567890123456789";
                    text.text = str;
                    text.ForceMeshUpdate();
                    return text;
                }
                if (targetType == typeof(Graphic)) {
                    return go.AddComponent<RawImage>();
                }
                if (typeof(Object).IsAssignableFrom(targetType)) {
                    if (targetType == typeof(Renderer)) {
                        var renderer = go.GetComponent<Renderer>();
                        Assert.IsNotNull(renderer);
                        if (tweenType == TweenAnimation.TweenType.MaterialPropertyBlockPropertyVector4) {
                            renderer.material = new Material(Shader.Find("ShaderWithVector4Property"));
                        }
                        return renderer;
                    }
                    var result = go.AddComponent(targetType);
                    if (result is ScrollRect scrollRect) {
                        scrollRect.content = go.GetComponent<RectTransform>();
                        Assert.IsNotNull(scrollRect.content);
                    }
                    return result;
                }
                return null;
            }

            const float duration = 0.1f;
            TweenAnimation.ValueWrapper startValue;
            TweenAnimation.ValueWrapper endValue;
            if (tweenType == TweenAnimation.TweenType.TextMaxVisibleCharacters) {
                startValue = 5f.ToContainer();
                endValue = 10f.ToContainer();
            } else {
                startValue = new Vector4(0.1f, 0.2f, 0.3f,0.4f).ToContainer();
                endValue = new Vector4(0.4f, 0.3f, 0.2f,0.1f).ToContainer();
            }

            string stringParam = GetStringParam();
            string GetStringParam() {
                switch (tweenType) {
                    case TweenAnimation.TweenType.MaterialPropertyBlockPropertyVector4:
                    case TweenAnimation.TweenType.MaterialPropertyVector4:
                        return "_ColorVector";
                    case TweenAnimation.TweenType.MaterialPropertyBlockColorProperty:
                    case TweenAnimation.TweenType.MaterialPropertyBlockAlphaProperty:
                    case TweenAnimation.TweenType.MaterialAlphaProperty:
                    case TweenAnimation.TweenType.MaterialColorProperty:
                        return "_Color";
                    case TweenAnimation.TweenType.MaterialPropertyBlockProperty:
                    case TweenAnimation.TweenType.MaterialProperty:
                        return "_Mode";
                    case TweenAnimation.TweenType.MaterialPropertyBlockTextureScale:
                    case TweenAnimation.TweenType.MaterialPropertyBlockTextureOffset:
                    case TweenAnimation.TweenType.MaterialTextureOffset:
                    case TweenAnimation.TweenType.MaterialTextureScale:
                        return "_MainTex";
                    default:
                        return string.Empty;
                }
            }

            var data = new TweenAnimation.Data {
                tweenType = tweenType,
                targets = new List<Object> { target },
                duration = duration,
                stringParam = stringParam,
                hasStartValue = TweenAnimation.Data.IsCustomTweenType(tweenType),
                startValue = startValue,
                endValue = endValue
            };
            const float shakeFrequency = 10f;
            switch (tweenType) {
                case TweenAnimation.TweenType.ShakeCamera:
                    data.shakeCameraStrengthFactor = startValue.single;
                    data.shakeFrequency = shakeFrequency;
                    break;
                case TweenAnimation.TweenType.ShakeLocalPosition:
                case TweenAnimation.TweenType.ShakeLocalRotation:
                case TweenAnimation.TweenType.ShakeScale:
                    data.shakeStrength = startValue.vector3;
                    data.shakeFrequency = shakeFrequency;
                    break;
                case TweenAnimation.TweenType.ShakeCustom:
                    data.shakeStrength = startValue.vector3;
                    data.shakeFrequency = shakeFrequency;
                    data.customData = new TweenAnimation.Data.Custom {
                        unityEventVector3 = new TweenAnimation.Data.Custom.UnityEventVector3()
                    };
                    break;
                case TweenAnimation.TweenType.CustomColor: {
                    var evt = new TweenAnimation.Data.Custom.UnityEventColor();
                    evt.AddListener(x => _ = x);
                    data.customData = new TweenAnimation.Data.Custom {
                        unityEventColor = evt
                    };
                    break;
                }
                case TweenAnimation.TweenType.CustomFloat: {
                    var evt = new TweenAnimation.Data.Custom.UnityEventFloat();
                    evt.AddListener(x => _ = x);
                    data.customData = new TweenAnimation.Data.Custom {
                        unityEventFloat = evt
                    };
                    break;
                }
                case TweenAnimation.TweenType.CustomRect: {
                    var evt = new TweenAnimation.Data.Custom.UnityEventRect();
                    evt.AddListener(x => _ = x);
                    data.customData = new TweenAnimation.Data.Custom {
                        unityEventRect = evt
                    };
                    break;
                }
                case TweenAnimation.TweenType.CustomVector2: {
                    var evt = new TweenAnimation.Data.Custom.UnityEventVector2();
                    evt.AddListener(x => _ = x);
                    data.customData = new TweenAnimation.Data.Custom {
                        unityEventVector2 = evt
                    };
                    break;
                }
                case TweenAnimation.TweenType.CustomVector3: {
                    var evt = new TweenAnimation.Data.Custom.UnityEventVector3();
                    evt.AddListener(x => _ = x);
                    data.customData = new TweenAnimation.Data.Custom {
                        unityEventVector3 = evt
                    };
                    break;
                }
                case TweenAnimation.TweenType.CustomVector4: {
                    var evt = new TweenAnimation.Data.Custom.UnityEventVector4();
                    evt.AddListener(x => _ = x);
                    data.customData = new TweenAnimation.Data.Custom {
                        unityEventVector4 = evt
                    };
                    break;
                }
                case TweenAnimation.TweenType.Callback:
                    data.customData = new TweenAnimation.Data.Custom {
                        callback = new UnityEvent()
                    };
                    break;
            }

            animationComponent.animation = new TweenAnimation {
                animations = new List<TweenAnimation.Data> { data },
                useUnscaledTime = tweenType == TweenAnimation.TweenType.GlobalTimeScale
            };

            foreach (var comp in go.GetComponentsInChildren<Component>()) {
                InternalEditorUtility.SetIsInspectorExpanded(comp, false);
            }
            InternalEditorUtility.SetIsInspectorExpanded(animationComponent, true);
            Tests.ExpandAllPropertiesInInspector(animationComponent);

            bool supportsStartValueGetter = !TweenAnimation.Data.IsCustomTweenType(tweenType);
            switch (tweenType) {
                case TweenAnimation.TweenType.Delay:
                case TweenAnimation.TweenType.Callback:
                case TweenAnimation.TweenType.Rotation:
                case TweenAnimation.TweenType.LocalRotation:
                case TweenAnimation.TweenType.RigidbodyMoveRotation:
                case TweenAnimation.TweenType.ShakeCamera:
                case TweenAnimation.TweenType.ShakeCustom:
                case TweenAnimation.TweenType.ScaleUniform:
                case TweenAnimation.TweenType.TweenAnimationComponent:
                // Setting up a scroll rect is a complex process, which this test doesn't cover
                case TweenAnimation.TweenType.UINormalizedPosition:
                case TweenAnimation.TweenType.UIHorizontalNormalizedPosition:
                case TweenAnimation.TweenType.UIVerticalNormalizedPosition:
                    supportsStartValueGetter = false;
                    break;
            }
            if (supportsStartValueGetter) {
                TweenData rt = new TweenData {
                    target = target,
                    endValueOrDiff = endValue,
                    cold = new ColdData {
                        longParam = Shader.PropertyToID(data.stringParam),
                        onValueChange = delegate {
                            Debug.LogError($"onValueChange should not be called {tweenType}");
                        }
                    },
                    id = 42
                };
                UnmanagedTweenData d = new UnmanagedTweenData {
                    isAlive = true,
                    tweenType = tweenType,
                    startValue = startValue,
                    id = 42
                };

                var shakeData = new ShakeData();
                shakeData.Setup(new ShakeSettings(Vector3.one), ref rt, ref d, target);
                rt.cold.shakeData = shakeData;

                if (tweenType == TweenAnimation.TweenType.GlobalTimeScale) {
                    d.startValue = 1f.ToContainer();
                }
                Utils.SetAnimatedValue(ref rt, ref d);
                if (testInspector) {
                    Selection.activeGameObject = go;
                    EditorWindow.GetWindow(inspectorWindowType);

                    bool isRigidbody = false;
                    switch (tweenType) {
                        case TweenAnimation.TweenType.RigidbodyMovePosition:
                        case TweenAnimation.TweenType.RigidbodyMovePosition2D:
                        case TweenAnimation.TweenType.RigidbodyMoveRotationQuaternion:
                        case TweenAnimation.TweenType.RigidbodyMoveRotation:
                        case TweenAnimation.TweenType.RigidbodyMoveRotation2D:
                            isRigidbody = true;
                            break;
                    }

                    yield return WaitInEditor();

                    if (isRigidbody) {
                    } else {
                        TweenAnimation.ValueWrapper savedStartValue = animationComponent.animation.animations[0].startValue;
                        if (Utils.TweenTypeToTweenData(tweenType).Item1 == PropType.Quaternion) {
                            Assert.AreEqual(startValue.quaternion.normalized, savedStartValue.quaternion.normalized);
                        } else {
                            const float tolerance = 0.0001f;
                            Assert.AreEqual(startValue.x, savedStartValue.x, tolerance);
                            if (savedStartValue.y != 0f) {
                                Assert.AreEqual(startValue.y, savedStartValue.y, tolerance);
                            }
                            if (savedStartValue.z != 0f) {
                                Assert.AreEqual(startValue.z, savedStartValue.z, tolerance);
                            }
                            if (Utils.IsShake(tweenType)) {
                                Assert.AreEqual(shakeFrequency, savedStartValue.w);
                            } else if (savedStartValue.w != 0f) {
                                Assert.AreEqual(startValue.w, savedStartValue.w, tolerance);
                            }
                        }
                    }
                }
            } else if (testInspector) {
                Selection.activeGameObject = go;
                EditorWindow.GetWindow(inspectorWindowType);
                yield return WaitInEditor();
            }

            animationComponent.animation.Trigger();
            var seq = animationComponent.animation._sequence;
            Assert.IsTrue(seq.isAlive);
            ColdData t = null;
            foreach (var child in seq.GetAllChildren()) {
                t = child;
            }
            Assert.IsNotNull(t);

            seq.Stop();
            Selection.activeGameObject = null;
            yield return WaitInEditor();
        }

        // while (true) {
        //     yield return null;
        // }

        if (testInspector) {
            EditorWindow.GetWindow<TestRunnerWindow>();
        }
        LogAssert.NoUnexpectedReceived();
    }

    IEnumerator WaitInEditor() {
        double startTime = EditorApplication.timeSinceStartup;
        while (EditorApplication.timeSinceStartup - startTime < 0.01) {
            yield return null;
        }
    }

    [UnityTest]
    public IEnumerator RecursiveTweenAnimationComponent() {
        LogAssert.Expect(LogType.Warning, new Regex("It's not allowed to reference 'TweenAnimationComponent' from itself"));
        var animationComponent = new GameObject().AddComponent<TweenAnimationComponent>();
        Tests.ExpandAllPropertiesInInspector(animationComponent);
        animationComponent.animation.animations.Add(new TweenAnimation.Data {
            tweenType = TweenAnimation.TweenType.TweenAnimationComponent,
            targets = new List<Object> { animationComponent }
        });

        Selection.activeGameObject = animationComponent.gameObject;
        Type inspectorWindowType = typeof(Editor).Assembly.GetType("UnityEditor.InspectorWindow");
        EditorWindow.GetWindow(inspectorWindowType);
        yield return WaitInEditor();
        Selection.activeGameObject = null;
        yield return WaitInEditor();
        Object.DestroyImmediate(animationComponent.gameObject);
    }

    [UnityTest]
    public IEnumerator RecursiveCyclicNesting() {
        for (int i = 0; i < 8; i++) {
            LogAssert.Expect(LogType.Error, new Regex("It's not allowed to reference 'TweenAnimationComponent' from itself"));
        }
        var a1 = new GameObject().AddComponent<TweenAnimationComponent>();
        var a2 = new GameObject().AddComponent<TweenAnimationComponent>();

        a1.animation.isReversible = true;
        a1.animation.animations.Add(new TweenAnimation.Data {
            tweenType = TweenAnimation.TweenType.TweenAnimationComponent,
            targets = new List<Object> { a2 }
        });

        a2.animation.isReversible = true;
        a2.animation.animations.Add(new TweenAnimation.Data {
            tweenType = TweenAnimation.TweenType.TweenAnimationComponent,
            targets = new List<Object> { a1 }
        });

        a1.animation.state = !a1.animation.state;
        a1.animation.Reset();
        a1.animation.Trigger();
        a1.animation.Complete();
        a1.animation.ToggleState();
        _ = a1.animation.isAlive;
        a1.animation.progressTotal = 0.1f;

        Selection.activeGameObject = a1.gameObject;
        yield return WaitInEditor();
        Selection.activeGameObject = null;
        yield return WaitInEditor();

        Object.DestroyImmediate(a1.gameObject);
        Object.DestroyImmediate(a2.gameObject);
    }

    [UnityTest]
    public IEnumerator TargetTweenAnimationComponentNullAnimation() {
        // Previously, TweenAnimation.Reset() called CreateSequence(), so got 2 errors.
        // But now Reset() in Edit Mode restores ini values directly, so we should get only 1 error.
        for (int _ = 0; _ < 1; _++) {
            LogAssert.Expect(LogType.Error, new Regex("Target's TweenAnimationComponent animation is null."));
        }
        var animationComponent1 = new GameObject().AddComponent<TweenAnimationComponent>();
        animationComponent1.animation = null;

        var animationComponent2 = new GameObject().AddComponent<TweenAnimationComponent>();
        Selection.activeGameObject = animationComponent2.gameObject;
        animationComponent2.animation.animations.Add(new TweenAnimation.Data {
            tweenType = TweenAnimation.TweenType.TweenAnimationComponent,
            targets = new List<Object> { animationComponent1 }
        });
        animationComponent2.animation.Trigger();
        yield return WaitInEditor();
        Selection.activeGameObject = null;
    }

    [UnityTest]
    public IEnumerator StartValue() {
        var target = new GameObject(nameof(StartValue)).transform;
        Selection.activeGameObject = target.gameObject;
        EditorWindow.GetWindow(typeof(Editor).Assembly.GetType("UnityEditor.InspectorWindow"));

        var animations = target.gameObject.AddComponent<TweenAnimationComponent>().animation.animations;
        var data = new TweenAnimation.Data {
            tweenType = TweenAnimation.TweenType.PositionX,
            targets = new List<Object> { target },
            hasStartValue = true
        };
        animations.Add(data);

        // startValue can be modified via Inspector when `hasStartValue == true`
        var startVal = Random.value * 10f;
        data.startValue = new TweenAnimation.ValueWrapper { x = startVal };
        animations[0] = data;
        yield return WaitInEditor();
        Assert.AreEqual(startVal, animations[0].startValue.x);

        // startValue is taken from the current when `hasStartValue == false`
        data.hasStartValue = false;
        animations[0] = data;
        var curVal = Random.value * 10f;
        target.position = new Vector3(curVal, Random.value, Random.value);
        yield return WaitInEditor();
        Assert.AreEqual(curVal, animations[0].startValue.x, 0.001f, $"startVal:{startVal} curVal:{curVal}");
    }

    [UnityTest]
    public IEnumerator EndValueEditing() {
        var target = new GameObject(nameof(EndValueEditing)).transform;
        Selection.activeGameObject = target.gameObject;
        EditorWindow.GetWindow(typeof(Editor).Assembly.GetType("UnityEditor.InspectorWindow"));

        var animationComponent = target.gameObject.AddComponent<TweenAnimationComponent>();
        var animations = animationComponent.animation.animations;
        float endVal = Random.value * 10f;
        var data = new TweenAnimation.Data {
            tweenType = TweenAnimation.TweenType.PositionX,
            targets = new List<Object> { target },
            endValue = new TweenAnimation.ValueWrapper { x = endVal }
        };
        animations.Add(data);

        Tests.ExpandAllPropertiesInInspector(animationComponent);

        // selecting endValue in the Inspector should modify the target value in the scene
        yield return WaitInEditor();
        int keyboardControl = ValueContainerStartEndPropDrawer._endValueControlId + 1;
        Assert.AreNotEqual(1, keyboardControl);
        ValueContainerStartEndPropDrawer._overrideKeyboardControl = keyboardControl;
        yield return WaitInEditor();
        Assert.AreEqual(endVal, target.localPosition.x);

        // deselecting endValue in the Inspector should restore the original value
        ValueContainerStartEndPropDrawer._overrideKeyboardControl = 0;
        while (ValueContainerStartEndPropDrawer._overrideKeyboardControl.HasValue) {
            // wait for ValueContainerStartEndPropDrawer to set _overrideKeyboardControl to null from OnGUI. Setting `GUIUtility.keyboardControl` outside the OnGUI context doesn't work.
            yield return null;
        }
        Assert.AreEqual(0f, target.localPosition.x);
        Object.DestroyImmediate(target.gameObject);
        // while (animations[0].hasStartValue) { yield return WaitInEditor(); }
    }

    [UnityTest]
    public IEnumerator NegativeCyclesShouldBeClamped() {
        var target = new GameObject(nameof(EndValueEditing)).transform;
        EditorWindow.GetWindow(typeof(Editor).Assembly.GetType("UnityEditor.InspectorWindow"));

        var animationComponent = target.gameObject.AddComponent<TweenAnimationComponent>();
        var animations = animationComponent.animation.animations;
        float endVal = Random.value * 10f;
        var data = new TweenAnimation.Data {
            tweenType = TweenAnimation.TweenType.PositionX,
            targets = new List<Object> { target },
            endValue = new TweenAnimation.ValueWrapper { x = endVal },
            cycles = -1
        };
        animations.Add(data);
        Tests.ExpandAllPropertiesInInspector(animationComponent);

        Assert.AreEqual(-1, animations[0].cycles);
        Selection.activeGameObject = target.gameObject;
        yield return WaitInEditor();
        Assert.AreEqual(1, animations[0].cycles);

        Selection.activeGameObject = null;
        data.cycles = 0;
        animations[0] = data;
        Assert.AreEqual(0, animations[0].cycles);
        Selection.activeGameObject = target.gameObject;
        yield return WaitInEditor();
        Assert.AreEqual(1, animations[0].cycles);
    }

    [UnityTest]
    public IEnumerator ResetSceneValues() {
        var parentTarget = GameObject.CreatePrimitive(PrimitiveType.Cube).transform;
        parentTarget.gameObject.name = nameof(parentTarget);
        Selection.activeTransform = parentTarget;
        EditorWindow.GetWindow(typeof(Editor).Assembly.GetType("UnityEditor.InspectorWindow"));

        var iniParentPos = new Vector3(1f, 2f, 3f);
        var targetParentPos = new Vector3(10f, 20f, 30f);
        parentTarget.position = iniParentPos;

        var iniNestedPos = new Vector3(4f, 5f, 6f);
        var startNestedPos = new Vector3(7f, 8f, 9f);
        var targetNestedPos = new Vector3(40f, 50f, 60f);
        var nestedTarget = GameObject.CreatePrimitive(PrimitiveType.Cube).transform;
        nestedTarget.gameObject.name = nameof(nestedTarget);
        nestedTarget.position = iniNestedPos;
        var nested = nestedTarget.gameObject.AddComponent<TweenAnimationComponent>();
        const float duration = 0.1f;
        nested.animation.animations.Add(new TweenAnimation.Data {
            tweenType = TweenAnimation.TweenType.Position,
            targets = new List<Object> { nestedTarget },
            startValue = new TweenAnimation.ValueWrapper { vector3 = startNestedPos },
            endValue = new TweenAnimation.ValueWrapper { vector3 = targetNestedPos },
            duration = duration
        });

        var parent = parentTarget.gameObject.AddComponent<TweenAnimationComponent>();
        var parentAnimations = parent.animation.animations;
        parentAnimations.AddRange(new [] {
            new TweenAnimation.Data {
                tweenType = TweenAnimation.TweenType.PositionX,
                targets = new List<Object> { parentTarget },
                endValue = new TweenAnimation.ValueWrapper { single = targetParentPos.x },
                duration = duration
            },
            new TweenAnimation.Data {
                tweenType = TweenAnimation.TweenType.PositionY,
                targets = new List<Object> { parentTarget },
                endValue = new TweenAnimation.ValueWrapper { single = targetParentPos.y },
                duration = duration
            },
            new TweenAnimation.Data {
                tweenType = TweenAnimation.TweenType.PositionZ,
                targets = new List<Object> { parentTarget },
                endValue = new TweenAnimation.ValueWrapper { single = targetParentPos.z },
                duration = duration
            },
            new TweenAnimation.Data {
                tweenType = TweenAnimation.TweenType.TweenAnimationComponent,
                targets = new List<Object> { nested },
                duration = duration
            }
        });

        yield return WaitInEditor();

        parent.animation.Trigger();
        parent.animation.Complete();

        Assert.AreEqual(targetParentPos, parentTarget.position);
        Assert.AreEqual(targetNestedPos, nestedTarget.position);
        Assert.IsFalse(parent.animation.state);
        Assert.IsFalse(nested.animation.state);

        Selection.activeTransform = null;
        yield return WaitInEditor();

        Assert.AreEqual(iniParentPos, parentTarget.position);
        Assert.AreEqual(iniNestedPos, nestedTarget.position);
        Assert.IsFalse(parent.animation.state);
        Assert.IsFalse(nested.animation.state);

        {
            // test isReversible state
            parent.animation.isReversible = true;
            parent.animation.Trigger();
            parent.animation.Complete();
            Assert.IsTrue(parent.animation.state);
            parent.animation.Trigger();
            parent.animation.Complete();
            Assert.IsFalse(parent.animation.state);
        }

        { // test nestedTweenAnimationIsReversed
            const int nestedAnimationIndex = 3;
            var d = parentAnimations[nestedAnimationIndex];
            d.nestedTweenAnimationIsReversed = true;
            parentAnimations[nestedAnimationIndex] = d;

            LogAssert.Expect(LogType.Error, new Regex(Constants.nestedAnimationShouldBeReversible));
            parent.animation.Trigger();
            parent.animation.Reset();

            nested.animation.isReversible = true;
            Selection.activeTransform = parentTarget;
            yield return WaitInEditor();
            parent.animation.Trigger();
            parent.animation.Complete();

            Assert.AreEqual(targetParentPos, parentTarget.position);
            Assert.AreEqual(startNestedPos, nestedTarget.position);
            Assert.IsTrue(parent.animation.state);
            Assert.IsFalse(nested.animation.state);

            Selection.activeTransform = null;
            yield return WaitInEditor();

            Assert.AreEqual(iniParentPos, parentTarget.position);
            Assert.AreEqual(iniNestedPos, nestedTarget.position);
            Assert.IsFalse(parent.animation.state);
            Assert.IsFalse(nested.animation.state);
        }

        // while (true) yield return WaitInEditor();
    }

    [Serializable] public abstract class BaseTest : MonoBehaviour { [SerializeField, UsedImplicitly] private TweenAnimation item; }
    [Serializable] public class DerivedTest : BaseTest { }
    [UnityTest]
    public IEnumerator InheritedPrivateMember() {
        var derived = new GameObject().AddComponent<DerivedTest>();
        Tests.ExpandAllPropertiesInInspector(derived);
        Selection.activeGameObject = derived.gameObject;
        yield return WaitInEditor();
    }

    #endif // PRIME_TWEEN_PRO
}
#endif
