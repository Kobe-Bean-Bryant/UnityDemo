// ReSharper disable AnnotateNotNullParameter
using UnityEngine;
#if UI_ELEMENTS_MODULE_INSTALLED
using UnityEngine.UIElements;
#endif

namespace PrimeTween {
    internal static class Extensions {
        internal static float CalcDistance(Vector3 v1, Vector3 v2) => Vector3.Distance(v1, v2);
        internal static float CalcDistance(Quaternion q1, Quaternion q2) => Quaternion.Angle(q1, q2);

        internal static float calcDelta(this float val, TweenAnimation.ValueWrapper prevVal) => val - prevVal.single;
        internal static double calcDelta(this double val, TweenAnimation.ValueWrapper prevVal) => val - prevVal.DoubleVal;
        internal static Color calcDelta(this Color val, TweenAnimation.ValueWrapper prevVal) => val - prevVal.color;
        internal static Vector2 calcDelta(this Vector2 val, TweenAnimation.ValueWrapper prevVal) => val - prevVal.vector2;
        internal static Vector3 calcDelta(this Vector3 val, TweenAnimation.ValueWrapper prevVal) => val - prevVal.vector3;
        internal static Vector4 calcDelta(this Vector4 val, TweenAnimation.ValueWrapper prevVal) => val - prevVal.vector4;
        internal static Quaternion calcDelta(this Quaternion val, TweenAnimation.ValueWrapper prevVal) => Quaternion.Inverse(prevVal.quaternion) * val;
        internal static Rect calcDelta(this Rect val, TweenAnimation.ValueWrapper prevVal) => new Rect(
            val.x - prevVal.x,
            val.y - prevVal.y,
            val.width - prevVal.z,
            val.height - prevVal.w);

        internal static Color WithAlpha(this Color c, float alpha) {
            c.a = alpha;
            return c;
        }

        internal static TweenAnimation.ValueWrapper ToContainer(this float f) => new TweenAnimation.ValueWrapper { single = f };
        internal static TweenAnimation.ValueWrapper ToContainer(this Vector2 v) => new TweenAnimation.ValueWrapper { vector2 = v };
        internal static TweenAnimation.ValueWrapper ToContainer(this Vector3 v) => new TweenAnimation.ValueWrapper { vector3 = v };
        internal static TweenAnimation.ValueWrapper ToContainer(this Vector4 v) => new TweenAnimation.ValueWrapper { vector4 = v };
        internal static TweenAnimation.ValueWrapper XYToContainer(this Vector4 v) => new TweenAnimation.ValueWrapper { vector2 = new Vector2(v.x, v.y) };
        internal static TweenAnimation.ValueWrapper ZWToContainer(this Vector4 v) => new TweenAnimation.ValueWrapper { vector2 = new Vector2(v.z, v.w) };
        internal static TweenAnimation.ValueWrapper ToContainer(this Color c) => new TweenAnimation.ValueWrapper { color = c };
        internal static TweenAnimation.ValueWrapper ToContainer(this Quaternion q) => new TweenAnimation.ValueWrapper { quaternion = q };
        internal static TweenAnimation.ValueWrapper ToContainer(this Rect r) => new TweenAnimation.ValueWrapper { rect = r };
        internal static TweenAnimation.ValueWrapper ToContainer(this double d) => new TweenAnimation.ValueWrapper { DoubleVal = d };

        internal static Vector2 WithComponent(this Vector2 v, int index, float val) {
            v[index] = val;
            return v;
        }

        internal static Vector3 WithComponent(this Vector3 v, int index, float val) {
            v[index] = val;
            return v;
        }

        #if !UNITY_2019_1_OR_NEWER || UNITY_UGUI_INSTALLED
        internal static Vector2 GetFlexibleSize(this UnityEngine.UI.LayoutElement target) => new Vector2(target.flexibleWidth, target.flexibleHeight);
        internal static void SetFlexibleSize(this UnityEngine.UI.LayoutElement target, Vector2 vector2) {
            target.flexibleWidth = vector2.x;
            target.flexibleHeight = vector2.y;
        }

        internal static Vector2 GetMinSize(this UnityEngine.UI.LayoutElement target) => new Vector2(target.minWidth, target.minHeight);
        internal static void SetMinSize(this UnityEngine.UI.LayoutElement target, Vector2 vector2) {
            target.minWidth = vector2.x;
            target.minHeight = vector2.y;
        }

        internal static Vector2 GetPreferredSize(this UnityEngine.UI.LayoutElement target) => new Vector2(target.preferredWidth, target.preferredHeight);
        internal static void SetPreferredSize(this UnityEngine.UI.LayoutElement target, Vector2 vector2) {
            target.preferredWidth = vector2.x;
            target.preferredHeight = vector2.y;
        }

        internal static Vector2 GetNormalizedPosition(this UnityEngine.UI.ScrollRect target) => new Vector2(target.horizontalNormalizedPosition, target.verticalNormalizedPosition);
        internal static void SetNormalizedPosition(this UnityEngine.UI.ScrollRect target, Vector2 vector2) {
            target.horizontalNormalizedPosition = vector2.x;
            target.verticalNormalizedPosition = vector2.y;
        }
        #endif

        #if UI_ELEMENTS_MODULE_INSTALLED
        internal static Vector2 GetTopLeft(this VisualElement e) {
            var resolvedStyle = e.resolvedStyle;
            return new Vector2(resolvedStyle.left, resolvedStyle.top);
        }
        internal static void SetTopLeft(this VisualElement e, Vector2 c) {
            var style = e.style;
            style.left = c.x;
            style.top = c.y;
        }
        internal static Rect GetResolvedStyleRect(this VisualElement e) {
            var resolvedStyle = e.resolvedStyle;
            return new Rect(
                resolvedStyle.left,
                resolvedStyle.top,
                resolvedStyle.width,
                resolvedStyle.height
            );
        }
        internal static void SetStyleRect(this VisualElement e, Rect c) {
            var style = e.style;
            style.left = c.x;
            style.top = c.y;
            style.width = c.width;
            style.height = c.height;
        }

        internal static Vector3 GetPosition(this ITransform e) {
            #if UNITY_6000_2_OR_NEWER
            return (e as VisualElement).resolvedStyle.translate;
            #else
            return e.position;
            #endif
        }
        internal static void SetPosition(this ITransform e, Vector3 pos) {
            #if UNITY_6000_2_OR_NEWER
            (e as VisualElement).style.translate = pos;
            #else
            e.position = pos;
            #endif
        }
        internal static Quaternion GetRotation(this ITransform e) {
            #if UNITY_6000_2_OR_NEWER
            return (e as ITransform).matrix.rotation;
            #else
            return e.rotation;
            #endif
        }
        internal static void SetRotation(this ITransform e, Quaternion rot) {
            #if UNITY_6000_2_OR_NEWER
            (e as VisualElement).style.rotate = rot;
            #else
            e.rotation = rot;
            #endif
        }
        internal static Vector3 GetScale(this ITransform e) {
            #if UNITY_6000_2_OR_NEWER
            return (e as VisualElement).resolvedStyle.scale.value;
            #else
            return e.scale;
            #endif
        }
        internal static void SetScale(this ITransform e, Vector3 scale) {
            #if UNITY_6000_2_OR_NEWER
            (e as VisualElement).style.scale = scale;
            #else
            e.scale = scale;
            #endif
        }
        #endif

        #if UNITY_2021_1_OR_NEWER
        static bool TryGetPropertyBlock(object target, out MaterialPropertyBlock result) {
            var renderer = target as Renderer;
            if (renderer.HasPropertyBlock()) {
                result = PrimeTweenManager.Instance.materialPropertyBlockForGetter;
                renderer.GetPropertyBlock(result);
                return true;
            }
            result = null;
            return false;
        }
        internal static bool TryGetPropertyBlockColor(object target, int propId, out Color result) {
            if (TryGetPropertyBlock(target, out var b) && b.HasColor(propId)) {
                result = b.GetColor(propId);
                return true;
            }
            result = default;
            return false;
        }
        internal static bool TryGetPropertyBlockVector(object target, int propId, out Vector4 result) {
            if (TryGetPropertyBlock(target, out var b) && b.HasVector(propId)) {
                result = b.GetVector(propId);
                return true;
            }
            result = default;
            return false;
        }
        internal static bool TryGetPropertyBlockFloat(object target, int propId, out float result) {
            if (TryGetPropertyBlock(target, out var b) && b.HasFloat(propId)) {
                result = b.GetFloat(propId);
                return true;
            }
            result = default;
            return false;
        }
        #endif
    }
}
